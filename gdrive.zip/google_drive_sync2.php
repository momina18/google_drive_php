<?php     
// Include configuration file 
require_once 'config1.php'; 
 
// Include and initialize Google Drive API handler class 
include_once 'GoogleDriveApi2.class.php'; 
$GoogleDriveApi = new GoogleDriveApi(); 
 
$statusMsg = $valErr = $access_token = ''; 
$status = 'danger'; 
 
// If the form is submitted 
if(isset($_POST['submit'])){ 
    // Validate form input fields 
    if(empty($_POST["file_id"])){ 
        $valErr .= 'Please enter ID of Google Drive file.'; 
    } 
     
    // Check whether user inputs are empty 
    if(empty($valErr)){ 
        $drive_file_id = $_POST["file_id"]; 
         
        // Store reference ID of file in SESSION 
        $_SESSION['last_file_id'] = $drive_file_id; 
         
        // Get the access token 
        if(!empty($_SESSION['google_access_token'])){ 
            $access_token = $_SESSION['google_access_token']; 
        }else{ 
            // Redirect to the Google authentication site 
            header("Location: $googleOauthURL"); 
            exit(); 
        } 
    }else{ 
        $statusMsg = '<p>Please fill all the mandatory fields:</p>'.trim($valErr, '<br/>'); 
    } 
}elseif(isset($_GET['code'])){ 
    // Get file reference ID from SESSION 
    $drive_file_id = $_SESSION['last_file_id']; 
 
    if(!empty($drive_file_id)){ 
        // Get the access token 
        if(!empty($_SESSION['google_access_token'])){ 
            $access_token = $_SESSION['google_access_token']; 
        }else{ 
            $data = $GoogleDriveApi->GetAccessToken(GOOGLE_CLIENT_ID, REDIRECT_URI, GOOGLE_CLIENT_SECRET, $_GET['code']); 
            $access_token = $data['access_token']; 
            $_SESSION['google_access_token'] = $access_token; 
        } 
    }else{ 
        $statusMsg = 'File reference not found!'; 
    } 
}else{ 
    $statusMsg = 'Unauthorized access!'; 
} 
 
if(!empty($access_token)){ 
    // Delete file from Google drive 
    try { 
        $drive_file_delete = $GoogleDriveApi->DeleteFile($access_token, $drive_file_id, $googleOauthURL); 
    } catch(Exception $e) { 
        $api_error = $e->getMessage(); 
    } 
     
    if($drive_file_delete && empty($api_error)){ 
        $status = 'success';  
        $statusMsg = "The file ID:$drive_file_id has been removed from Google Drive successfully!"; 
             
        unset($_SESSION['last_file_id']); 
    }else{ 
        $statusMsg = 'File delete failed: '.$api_error; 
    } 
}else{ 
    unset($_SESSION['google_access_token']); 
    $statusMsg = !empty($statusMsg)?$statusMsg:'Failed to fetch access token! Click to <a href="'.$googleOauthURL.'">authenticate with Google Drive</a>'; 
} 
 
$_SESSION['status_response'] = array('status' => $status, 'status_msg' => $statusMsg); 
 
header("Location: delete.php"); 
exit(); 
 
?>