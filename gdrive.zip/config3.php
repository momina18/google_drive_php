<?php 
 
// Folder to store files 
$target_folder = 'uploads'; 
 
// Database configuration    
// Database configuration    
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 
define('DB_NAME', 'googledrive'); 
 
// Google API configuration 
define('GOOGLE_CLIENT_ID', '812066020696-nm186cdtii89din4o6op9qvkcjsfpobs.apps.googleusercontent.com'); 
define('GOOGLE_CLIENT_SECRET', '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'); 
define('GOOGLE_OAUTH_SCOPE', 'https://www.googleapis.com/auth/drive'); 
define('REDIRECT_URI', 'http://localhost/gdrive/google_drive_sync3.php'); 
 
// Google API configuration 

 

 
// Google OAuth URL 
$googleOauthURL = 'https://accounts.google.com/o/oauth2/auth?scope=' . urlencode(GOOGLE_OAUTH_SCOPE) . '&redirect_uri=' . REDIRECT_URI . '&response_type=code&client_id=' . GOOGLE_CLIENT_ID . '&access_type=online'; 


// Start session 
if(!session_id()) session_start(); 
 
?>