<?php 
// Include configuration file 
include_once 'config3.php'; 
 
$status = $statusMsg = ''; 
if(!empty($_SESSION['status_response'])){ 
    $status_response = $_SESSION['status_response']; 
    $status = $status_response['status']; 
    $statusMsg = $status_response['status_msg']; 
     
    unset($_SESSION['status_response']); 
} 
?>

<!-- Status message -->
<?php if(!empty($statusMsg)){ ?>
    <div class="alert alert-<?php echo $status; ?>"><?php echo $statusMsg; ?></div>
<?php } ?>

<div class="col-md-12">
    <form method="post" action="google_drive_sync3.php" class="form">
        <div class="form-group">
            <label>Drive File ID:</label>
            <input type="text" name="file_id" class="form-control" placeholder="Enter ID of Google Drive file">
        </div>
        <div class="form-group">
            <input type="submit" class="form-control btn-primary" name="submit" value="Download"/>
        </div>
    </form>
</div>