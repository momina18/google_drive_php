<?php
// Database configuration
require_once 'config.php'; 
 
// Create database connection 
$db = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME); 

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$status = $statusMsg = ''; 
if (!empty($_SESSION['status_response'])){ 
    $status_response = $_SESSION['status_response']; 
    $status = $status_response['status']; 
    $statusMsg = $status_response['status_msg']; 
    unset($_SESSION['status_response']); 
}
$sql = "SELECT * FROM drive_files";
$result = mysqli_query($db, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploaded Files</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
 
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <style>
        .btn-add {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-bottom: 20px;
            cursor: pointer;
            border-radius: 5px;
        }

        .btn-add:hover {
            background-color: #45a049;
        }

        .btn-action {
            margin-right: 5px;
        }
        .btn-edit {
            color: black;
        }
    </style>
</head>
<body class="bg-content">
    <main class="dashboard d-flex">
        <!-- <?php include "component/sidebar.php"; ?> -->
        <div class="container-fluid px">
            <!-- <?php include "component/header.php"; ?> -->
            <a href="index.php" class="btn btn-primary btn-add float-end">Add</a> 
            <section class="text-right left">
                <h3 class="m-4"></h3>

                <?php if(!empty($statusMsg)){ ?>
                    <div class="alert alert-<?php echo $status; ?> w-25 m-auto"><?php echo $statusMsg; ?></div>
                <?php } ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>File Name</th>
                                <th>Upload Date</th>
                                <th>Actions</th>  
                            </tr>
                        </thead>
                     
                        <tbody>
                            <?php 
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>".$row['id']."</td>";
                                echo "<td>".$row['file_name']."</td>";
                                echo "<td>".$row['created']."</td>";
                                echo "<td>
                                    <a href='share.php?id=".$row['id']."' class='btn btn-secondary btn-sm btn-action btn-sharelink'>Sharelink</a>
                                    <a href='delete.php?id=".$row['id']."' class='btn btn-danger btn-sm btn-action'>Delete</a>
                                    <a href='download.php?id=".$row['id']."' class='btn btn-success btn-sm btn-action'>Download</a>
                                </td>"; 
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
