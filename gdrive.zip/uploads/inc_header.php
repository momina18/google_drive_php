<div style="background:#a12935; padding:0px;">
 <a class="toggleMenu" href="#"></a>


<ul class="nav">

	<li class="test"><a href="index.php" class="smooth-bt">HOME</a>
        <ul>
            <li><a href="aboutSNDTWU.php" class="smooth-bt">About SNDTWU</a></li>
            <li><a href="aboutus.php" class="smooth-bt">ABOUT US</a></li>
            <li><a href="mission.php" class="smooth-bt">Mission / Vision</a></li>
            <li><a href="mangcouncil.php" class="smooth-bt">Office Bearers</a></li> 
            <li><a href="administrative-team.php" class="smooth-bt">Administrative Team</a></li> 
            <li><a href="organograms.php" class="smooth-bt">Organograms</a></li> 
            <li><a href="corevalues.php" class="smooth-bt">Core Values</a></li> 
         </ul> 
     </li>	



     <li><a href="#" class="smooth-bt">Admissions</a>
        <ul>
            <li><a href="fyjc-admission.php" class="smooth-bt">Junior College</a></li>
            <li><a href="fybcom-admission.php" class="smooth-bt">Degree College</a></li>
            <li><a href="pg-admission.php" class="smooth-bt">Post Graduate</a></li>           
        </ul>       
     </li>

     <li><a href="#" class="smooth-bt">Programs Offered</a>
        <ul>
            <li><a href="junior-courses.php" class="parent">Junior College</a></li>
            <li><a href="programsOffered-degree.php" class="smooth-bt">Degree College</a></li>
       		<li><a href="programsOffered-pg.php" class="smooth-bt">Post Graduate</a></li>
        	<li><a href="value-added-courses.php" class="smooth-bt">Value Added Courses</a></li>
        	<li><a href="distance-education.php" class="smooth-bt">Distance Education</a></li>
        </ul>
     </li>

    <li><a href="#" class="smooth-bt">Faculty</a>
        <ul>
            <li><a href="jrcolgstaff.php" class="smooth-bt">Junior College</a></li>
            <li><a href="faculty-degree.php" class="smooth-bt">Degree College</a></li>
            <li><a href="faculty-pg.php" class="smooth-bt">Post Graduate</a></li>
            <li><a href="images/pdf/profEthics.pdf" target="_blank" class="smooth-bt">Professional Ethics</a></li>
        </ul>
    </li>

    <li><a href="#" class="smooth-bt">College Committees</a>
    	<ul>
        	<li><a href="#" class="smooth-bt">Statutory Committees</a>
            	<ul>
					<li><a href="governing-body.php" class="smooth-bt">Governing Body</a></li>
                    <li><a href="academic-council.php" class="smooth-bt">Academic Council</a></li>
                    <li><a href="finance-committee.php" class="smooth-bt">Finance Committee</a></li>
                	<li><a href="images/pdf/rti.pdf" target="_blank" class="smooth-bt">RTI</a></li>
                    <li><a href="internal_complaints.php" class="smooth-bt">Internal Complaints Committee</a></li>
                    <li><a href="anti_ragging.php" class="smooth-bt">Anti – Ragging Cell</a></li>
                    <li><a href="grievance_redressal.php" class="smooth-bt">Grievance Redressal</a></li>
                </ul>
            </li>

            <li><a href="#" class="smooth-bt">Non – Statutory Committees</a>
            	<ul>
                	<li><a href="cdc.php" class="smooth-bt">College Development Committee</a></li>
                    <li><a href="#" class="smooth-bt">IQAC 'UTTHAAN'</a>
                    	<ul>
                        	<li><a href="composition.php" class="smooth-bt">Composition</a></li>
                            <li><a href="minutes-of-meeting.php" class="smooth-bt">Minutes of Meetings</a></li>
                            <li><a href="images/pdf/IQAC-report.pdf" target="_blank" class="smooth-bt">Reports</a></li>
                            <li><a href="aqar.php" class="smooth-bt">AQAR</a></li>
                            <li><a href="utthan-news.php" class="smooth-bt">Newsletter</a></li>
                            <li><a href="str-plan.php" class="smooth-bt">Strategic Plans & Deployment Documents</a></li>
                        </ul>
                    </li>

                    <li><a href="#" class="smooth-bt">Examination Committee</a>
                    	<ul>
                        	<li><a href="comp-exam-comt.php" class="smooth-bt">Composition</a></li>
                        	<li><a href="comp-mint-meet.php" class="smooth-bt">Minutes of Meetings</a></li>                            
                       </ul>
                    </li>
                </ul>
            </li>

            <li><a href="#" target="_blank" class="smooth-bt">Other Committees</a></li>
        </ul>
    </li> 



   <li><a href="#" class="smooth-bt">Student Support</a>    	
    	<ul>
        	<li><a href="freeships_scholarships.php" class="smooth-bt">Freeships & Scholarships</a></li>
            <li><a href="counselling_cell.php" class="smooth-bt">Counselling Cell</a>
            	<ul>
                	<li><a href="wecare.php" class="smooth-bt">We Care</a></li>
                </ul>            
            </li>
        	<li><a href="#" class="smooth-bt">Placement Cell</a>
                <ul>
                    <li><a href="placement.php" class="smooth-bt">Placement Cell Activities </a></li>
                    <li><a href="employability.php" class="smooth-bt">Employability Skill Training Programs </a></li>
                </ul>
            </li>
            <li><a href="student_council.php" class="smooth-bt">Students’ Council</a></li>
            <li><a href="academic_adv_center.php" class="smooth-bt">Academic Advancement Center</a></li>
            <li><a href="tcce.php" class="smooth-bt">TCCE</a></li>
        </ul> 
    </li>

    <li><a href="#" class="smooth-bt">NIRF/NAAC</a>
    	<ul>
        <li><a href="images/pdf/nirf-2024.pdf" class="smooth-bt" target="_blank" >NIRF 2024</a></li>
        <li><a href="AQAR_2022-23.php" class="smooth-bt">AQAR 2022-23</a></li>
        	<li><a href="images/pdf/nirf-2022.pdf" target="_blank" class="smooth-bt">NIRF 2022</a></li>
            <li><a href="images/pdf/nirf-2021.pdf" target="_blank" class="smooth-bt">NIRF 2021</a></li>
            <li><a href="#" class="smooth-bt">NAAC 2019-20</a>
            	<ul>
                	<li><a href="ssr.php" class="smooth-bt">SSR- Criterion Documents</a></li>
            		<li><a href="final-report.php" class="smooth-bt">Final SSR Report</a></li>
                </ul>
            </li>
			<li><a href="aqar20-21.php" class="smooth-bt">AQAR 2020-21</a></li>
			<li><a href="aqar21-22.php" class="smooth-bt">AQAR 2021-22</a></li>
        </ul>
    </li>
    
    <li><a href="#" class="smooth-bt">Extra Curricular activities</a>
    	<ul>
        	<li><a href="nss.php" class="smooth-bt">NSS</a></li>
            <li><a href="ncc.php" class="smooth-bt">NCC</a></li>
            <li><a href="sports.php" class="smooth-bt">SPORTS</a></li>
        </ul>
    </li>

    <li><a href="learn.php" class="smooth-bt">Learning Centres</a></li>

  	<!--<li><a href="contact.php">Contact Us</a></li>-->

  

</ul>



</div>



<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.2.min.js"></script>

<script type="text/javascript" src="js/script.js"></script>

<div class="clearfix"></div> 