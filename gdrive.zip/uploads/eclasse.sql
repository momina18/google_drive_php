-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2024 at 10:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eclasse`
--

-- --------------------------------------------------------

--
-- Table structure for table `drive_files`
--

CREATE TABLE `drive_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `drive_file_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drive_files`
--

INSERT INTO `drive_files` (`id`, `file_name`, `drive_file_id`, `created`) VALUES
(1, 'Amazon Elastic Compute Cloud.docx', '1CEyPrb8cHRains0euKOsTaCn5p8H3tFf', '2024-03-03 13:52:54'),
(2, 'KASHMITA PROPERTIES.docx', '1zDC0FYR3zJmk16GFnw2MS2wnMmqWIKeY', '2024-03-03 13:53:14'),
(3, 'Book1.xlsx', '1N6iuQQ9G9rSLlFxTZJukJzjIBKjR7zne', '2024-03-03 13:53:23'),
(4, 'script (3).docx', '1cNUjnm8JMYlPL3k928RPfDrXwxA9E7dG', '2024-03-03 13:53:32'),
(5, 'script.docx', '1ESPq7Rumy5F7LJdFOdVertkQvKso6y9Z', '2024-03-03 13:53:43'),
(78, 'Amazon Elastic Compute Cloud.docx', '1lvNbnhHT-bT7680NhkOTlqc8A8qtFObq', '2024-03-03 14:30:10'),
(79, 'tempCodeRunnerFile.py', '1SNd9YH1UiHSL6lTmBx89e5RRJnKYEPXA', '2024-03-03 14:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `Email`, `Password`) VALUES
(1, 'swati', 'swatiojha2701@gmail.com', 'saketschool2701');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `drive_files`
--
ALTER TABLE `drive_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `drive_files`
--
ALTER TABLE `drive_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
